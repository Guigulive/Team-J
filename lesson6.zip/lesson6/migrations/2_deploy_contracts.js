var ConvertLib = artifacts.require("./ConvertLib.sol");
var Ownable = artifacts.require("./Ownable.sol");
var PayRoll = artifacts.require("./PayRoll.sol");
var SafeMath = artifacts.require("./SafeMath.sol");

module.exports = function(deployer) {
  deployer.deploy(ConvertLib);
  deployer.deploy(Ownable);
  deployer.deploy(SafeMath);
  
  deployer.link(Ownable, PayRoll);
  deployer.link(SafeMath, PayRoll);

  deployer.deploy(PayRoll);//after link
};
