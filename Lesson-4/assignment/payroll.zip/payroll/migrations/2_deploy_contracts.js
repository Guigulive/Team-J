var ownable = artifacts.require("./Ownable.sol");
var safeMath = artifacts.require("./SafeMath.sol");
var payroll = artifacts.require("./Payroll.sol");

module.exports = function(deployer) {


  deployer.deploy(ownable);
deployer.deploy(safeMath);
deployer.link(safeMath,payroll);
deployer.deploy(payroll);
};
